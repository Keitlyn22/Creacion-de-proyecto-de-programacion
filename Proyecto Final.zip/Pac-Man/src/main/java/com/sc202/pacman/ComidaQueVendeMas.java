
package com.sc202.pacman;

import ComidaPorDia.ComidaPorDia;
import javax.swing.JOptionPane;

public class ComidaQueVendeMas {
    
    public static int Hamburguesas=ComidaPorDia.Hamburguesas;
    public static int Papas=ComidaPorDia.Papas;
    public static int Pollo=ComidaPorDia.Pollo;
    public static int HotDog=ComidaPorDia.HotDog;
    
    public void LaMasVendida(){
        
        if(Hamburguesas>Papas && Hamburguesas>Pollo && Hamburguesas>HotDog){
            JOptionPane.showMessageDialog(null, "La comida que más se vende es la hamburguesa");
            System.out.println("La comida que mas se vende es la hamburguesa");
        }
        if(Papas>Hamburguesas && Papas>Pollo && Papas>HotDog){
            JOptionPane.showMessageDialog(null, "La comida que más se vende son las papas ");
           System.out.println("La comida que mas se vende son las papas"); 
        }
        if(Pollo>Hamburguesas && Pollo>Papas && Pollo>HotDog){
            JOptionPane.showMessageDialog(null, "La comida que más se vende es el pollo ");
            System.out.println("La comida que mas se vende es el pollo");
        }
        if(HotDog>Hamburguesas && HotDog>Papas && HotDog>Pollo){
            JOptionPane.showMessageDialog(null, "La comida que más se vende es el hot dog ");
            System.out.println("La comida que mas se vende es el hot dog");
        }
    }
    
}
